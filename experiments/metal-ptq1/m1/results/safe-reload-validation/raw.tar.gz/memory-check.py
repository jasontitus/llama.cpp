import json,os,pathlib,subprocess,time,urllib.request,socket,re,hashlib
root=pathlib.Path.cwd(); out=root/'outputs/m1-safe-reload-validation'; rows=[]
clean={k:v for k,v in os.environ.items() if not k.startswith(('GGML_','LLAMA_ARG_'))}
profile=dict(GGML_METAL_PTQ1_MULTICOL='1',GGML_METAL_PTQ1_MULTICOL_MAX='8',GGML_METAL_PTQ1_GLU='1',GGML_METAL_PTQ1_STAGE='0',GGML_GDN_ROWS_PLAIN='1',GGML_METAL_SMALLM_MM='1')
for build in ['build-tuning-r4','build-tuning']:
 for mode in ['off','m1']:
  for mtp in [False,True]:
   name=f'{build}-{mode}-mtp{int(mtp)}'; log=out/(name+'.log')
   with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
   model=root/('work/mtp/Ternary-Bonsai-2-27B-PTQ1_0-mtp.gguf' if mtp else 'work/models/Ternary-Bonsai-2-27B-PTQ1_0.gguf')
   cmd=[str(root/'work'/build/'bin/llama-server'),'-m',str(model),'-c','4096','-b','512','-ub','512','-ngl','99','--device','MTL0','-fa','on','-np','1','-t','16','--jinja','--host','127.0.0.1','--port',str(port),'--no-context-shift','--cache-ram','0','-lv','4']
   cmd+=['--spec-type','draft-mtp','--spec-draft-n-max','1','--spec-draft-n-min','0','--spec-draft-p-min','0'] if mtp else ['--spec-type','none']
   with log.open('w') as f:
    p=subprocess.Popen(cmd,env=dict(clean,**(profile if mode=='m1' else {})),stdout=f,stderr=f)
    try:
     deadline=time.monotonic()+180
     while True:
      try:
       with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=2) as r:
        if json.load(r).get('status')=='ok': break
      except Exception: pass
      if p.poll() is not None or time.monotonic()>deadline: raise RuntimeError(name+' startup failed')
      time.sleep(.5)
     rss=subprocess.check_output(['ps','-o','rss=','-p',str(p.pid)],text=True).strip()
    finally:
     p.terminate()
     try: p.wait(timeout=20)
     except subprocess.TimeoutExpired: p.kill();p.wait()
   text=log.read_text(); lines=[s for s in text.splitlines() if re.search(r'compute buffer size|KV buffer size|model buffer size|output buffer size',s)]
   row=dict(name=name,command=cmd,flags=profile if mode=='m1' else {},startup_rss_kib=int(rss),buffers=lines,server_sha256=hashlib.sha256(pathlib.Path(cmd[0]).read_bytes()).hexdigest())
   rows.append(row); (out/'memory.json').write_text(json.dumps(rows,indent=2)); print(name,rss,lines,flush=True)
